

const number1 = document.querySelectorAll(".element1")
number1.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const number2 = document.querySelectorAll(".element2")
number2.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const number3 = document.querySelectorAll(".element3")
number3.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})



const number5 = document.querySelectorAll(".element5")
number5.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const number6 = document.querySelectorAll(".element6")
number6.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const number7 = document.querySelectorAll(".element7")
number7.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})



const number9 = document.querySelectorAll(".element9")
number9.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const number10 = document.querySelectorAll(".element10")
number10.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const number11 = document.querySelectorAll(".element11")
number11.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})


const number14 = document.querySelectorAll(".element14")
number14.forEach((elem) => {
    elem.addEventListener('click', () => {
        let inner = elem.innerText
        let output = mohasebe.innerText
        mohasebe.innerText = output + inner
    })
})

const CE = document.querySelectorAll(".element-Exceptional1")
CE.forEach((elem) => {
    elem.addEventListener('click', () => {
        mohasebe.innerText = ""
    })
})
const C = document.querySelectorAll(".element-Exceptional2")
C.forEach((elem) => {
    elem.addEventListener('click', () => {
        mohasebe.innerText = ""
    })
})

const delet = document.querySelectorAll(".element-Exceptional3")
delet.forEach((elem) => {
    elem.addEventListener('click', () => {
        let output = mohasebe.innerText
        mohasebe.innerText = output.substring(0, output.length - 1);
    })
})

const divice = document.querySelectorAll(".element-Exceptional4")
divice.forEach((elem) => {
    elem.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.length > 0 && output.charAt(output.length - 1) !== '/') {
            mohasebe.innerText = output + "/" //chat gpt
        }
    })
})
const equal = document.querySelectorAll(".element16")
equal.forEach((elem2) => {
    elem2.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.includes("/")) {
            let godakonande = output.split("/")
            adad = godakonande[0]
            adad2 = godakonande[1]
            let num1 = adad
            let num2 = adad2
            if (!isNaN(num1) && !isNaN(num2) && num2 !== 0) { //chat gpt
                let divice2 = num1 / num2
                mohasebe.innerText = divice2
            }
        }
    })
})

const xmark = document.querySelectorAll(".element4")
xmark.forEach((elem) => {
    elem.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.length > 0 && output.charAt(output.length - 1) !== '*') {
            mohasebe.innerText = output + "*"
        }
    })
})
const equal2 = document.querySelectorAll(".element16")
equal2.forEach((elem2) => {
    elem2.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.includes("*")) {
            let godakonande = output.split("*")
            adad = godakonande[0]
            adad2 = godakonande[1]
            let num1 = adad
            let num2 = adad2
            if (!isNaN(num1) && !isNaN(num2) && num2 !== 0) {
                let divice2 = num1 * num2
                mohasebe.innerText = divice2
            }
        }
    })
})

const minus = document.querySelectorAll(".element8")
minus.forEach((elem) => {
    elem.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.length > 0 && output.charAt(output.length - 1) !== '-') {
            mohasebe.innerText = output + "-"
        }
    })
})

const equal3 = document.querySelectorAll(".element16")
equal3.forEach((elem2) => {
    elem2.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.includes("-")) {
            let godakonande = output.split("-")
            adad = godakonande[0]
            adad2 = godakonande[1]
            let num1 = adad
            let num2 = adad2
            if (!isNaN(num1) && !isNaN(num2) && num2 !== 0) {
                let divice2 = num1 - num2
                mohasebe.innerText = divice2
            }
        }
    })
})

const plus = document.querySelectorAll(".element12")
plus.forEach((elem) => {
    elem.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.length > 0 && output.charAt(output.length - 1) !== '+') {
            mohasebe.innerText = output + "+"
        }
    })
})

const equal4 = document.querySelectorAll(".element16")
equal4.forEach((elem2) => {
    elem2.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.includes("+")) {
            let godakonande = output.split("+")
            adad = godakonande[0]
            adad2 = godakonande[1]
            let num1 = Number(adad)
            let num2 = Number(adad2)
            if (!isNaN(num1) && !isNaN(num2) && num2 !== 0) {
                let divice2 = num1 + num2
                mohasebe.innerText = divice2
            }
        }
    })
})

const baghimande = document.querySelectorAll(".element13")
baghimande.forEach((elem) => {
    elem.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.length > 0 && output.charAt(output.length - 1) !== '%') {
            mohasebe.innerText = output + "%"
        }
    })
})
const equal5 = document.querySelectorAll(".element16")
equal5.forEach((elem2) => {
    elem2.addEventListener('click', () => {
        let output = mohasebe.innerText
        if (output.includes("%")) {
            let godakonande = output.split("%")
            adad = godakonande[0]
            adad2 = godakonande[1]
            let num1 = parseFloat(adad)
            let num2 = parseFloat(adad2)
            if (!isNaN(num1) && !isNaN(num2) && num2 !== 0) {
                let divice2 = num1 % num2
                mohasebe.innerText = divice2
            }
        }
    })
})


const body = document.querySelector(".body")
const btns = document.querySelectorAll('button')
const darkANDlight = document.querySelectorAll(".p-back")
const koll = document.querySelector(".koll")
const div = document.querySelector(".div1")
let darking = false
darkANDlight.forEach((eleman) => {
    eleman.addEventListener('click', () => {
        darking = !darking
        if (darking) {
            body.style.backgroundColor = 'black'
            btns.forEach((btn) => {
                btn.style.backgroundColor = 'black'
                btn.style.color = 'white'
                btn.style.border = '2px solid white'
                // btn.hover.color = 'crimson'
            })
            koll.style.border = '2px solid white'
            div.style.border = '2px solid white'
            div.style.backgroundColor = 'black'
            javab.style.color = 'white'
            eleman.style.color = 'white'
            eleman.style.border = '2px solid white'
        } else {
            body.style.backgroundColor = 'white'
            btns.forEach((btn) => {
                btn.style.backgroundColor = 'white'
                btn.style.color = 'black'
                btn.style.border = '2px solid black'
                // btn.hover.color = 'crimson'
            })
            koll.style.border = '2px solid black'
            div.style.border = '2px solid black'
            div.style.backgroundColor = 'white'
            javab.style.color = 'black'
            eleman.style.color = 'black'
            eleman.style.border = '2px solid black'
        }

    })
})

const purpleANDpink = document.querySelectorAll(".p-back2")
let darking2 = false

purpleANDpink.forEach((eleman) => {
    eleman.addEventListener('click', () => {
        darking2 = !darking2
        if (darking2) {
            body.style.backgroundColor = 'rgba(204, 76, 208, 0.911)'
            btns.forEach((btn) => {
                btn.style.backgroundColor = 'rgba(86, 2, 86, 0.884)'
                btn.style.color = 'rgba(204, 76, 208, 0.911)'
                btn.style.border = '2px solid rgba(86, 2, 86, 0.884)'
                // btn.hover.color = 'crimson'
            })
            koll.style.border = '2px solid rgba(86, 2, 86, 0.884)'
            div.style.border = '2px solid rgba(86, 2, 86, 0.884)'
            div.style.backgroundColor = 'rgba(86, 2, 86, 0.884)'
            javab.style.color = 'rgba(204, 76, 208, 0.911)'
            eleman.style.color = 'rgba(86, 2, 86, 0.884)'
            eleman.style.border = '2px solid rgba(86, 2, 86, 0.884)'
        } else {
            body.style.backgroundColor = 'white'
            btns.forEach((btn) => {
                btn.style.backgroundColor = 'white'
                btn.style.color = 'black'
                btn.style.border = '2px solid black'
                // btn.hover.color = 'crimson'
            })
            koll.style.border = '2px solid black'
            div.style.border = '2px solid black'
            div.style.backgroundColor = 'white'
            javab.style.color = 'black'
            eleman.style.color = 'black'
            eleman.style.border = '2px solid black'
        }

    })
})

let adad
let adad2
let javab = document.querySelector(".javab")
let mohasebe = javab


